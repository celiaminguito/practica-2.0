package aplicacion;

import dominio.*;
//import interfaz.Interfaz;

public class Principal{
    public static void main(String[] args){
        interfaz.Interfaz.ejecutar(args);
    }
     
}
