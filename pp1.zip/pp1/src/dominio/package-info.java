/**
*Este paquete contiene las clases sobre el tema que trata la aplicacion, en concreto, todo aquello relacionado con los coches, como son la clase 'Coche.java' o la clase 'Catalogo.java'.
*/

package dominio;
